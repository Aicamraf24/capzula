package com.capsulas.item;

import com.capsulas.Capsulas;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;

public class ModItems {
    public static final Item CAPSULE = register("capsule", false, 16);
    public static final Item CAPSULE_FILLED = register("capsule_filled", true, 1);

    private static Item register(String name, boolean filled, int maxStack) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, Capsulas.id(name));
        Item.Properties props = new Item.Properties().setId(key).stacksTo(maxStack);
        return Registry.register(BuiltInRegistries.ITEM, key, new CapsuleItem(props, filled));
    }

    public static void init() {
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.TOOLS_AND_UTILITIES)
                .register(entries -> entries.accept(CAPSULE));
    }
}
