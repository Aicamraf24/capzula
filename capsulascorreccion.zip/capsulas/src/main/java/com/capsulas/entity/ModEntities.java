package com.capsulas.entity;

import com.capsulas.Capsulas;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

public class ModEntities {
    private static final ResourceKey<EntityType<?>> THROWN_CAPSULE_KEY =
            ResourceKey.create(Registries.ENTITY_TYPE, Capsulas.id("thrown_capsule"));

    public static final EntityType<ThrownCapsule> THROWN_CAPSULE = Registry.register(
            BuiltInRegistries.ENTITY_TYPE,
            THROWN_CAPSULE_KEY,
            EntityType.Builder.<ThrownCapsule>of(ThrownCapsule::new, MobCategory.MISC)
                    .sized(0.25F, 0.25F)
                    .clientTrackingRange(4)
                    .updateInterval(10)
                    .build(THROWN_CAPSULE_KEY));

    public static void init() {
        // fuerza la carga de la clase (y el registro)
    }
}
