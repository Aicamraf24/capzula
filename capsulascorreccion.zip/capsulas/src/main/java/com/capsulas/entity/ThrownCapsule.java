package com.capsulas.entity;

import com.capsulas.item.CapsuleItem;
import com.capsulas.item.ModItems;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.throwableitemprojectile.ThrowableItemProjectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;

public class ThrownCapsule extends ThrowableItemProjectile {

    public ThrownCapsule(EntityType<? extends ThrownCapsule> type, Level level) {
        super(type, level);
    }

    public ThrownCapsule(Level level, LivingEntity owner, ItemStack stack) {
        super(ModEntities.THROWN_CAPSULE, owner, level, stack);
    }

    @Override
    protected Item getDefaultItem() {
        return ModItems.CAPSULE;
    }

    /** Golpea a un mob: si la cápsula está vacía, lo captura. */
    @Override
    protected void onHitEntity(EntityHitResult hit) {
        super.onHitEntity(hit);
        if (!(level() instanceof ServerLevel server)) return;

        ItemStack stack = getItem();
        if (stack.is(ModItems.CAPSULE)
                && hit.getEntity() instanceof Mob mob
                && CapsuleItem.canCapture(mob)) {
            ItemStack filled = CapsuleItem.capture(server, mob);
            if (filled != null) {
                deliver(server, filled);
                discard();
            }
        }
    }

    /** Golpea una superficie: si la cápsula está llena, libera al mob. */
    @Override
    protected void onHitBlock(BlockHitResult hit) {
        super.onHitBlock(hit);
        if (!(level() instanceof ServerLevel server)) return;

        ItemStack stack = getItem();
        if (stack.is(ModItems.CAPSULE_FILLED) && CapsuleItem.release(server, stack, hit)) {
            deliver(server, new ItemStack(ModItems.CAPSULE));
            discard();
        }
    }

    /** Si no pasó nada especial, la cápsula cae como ítem donde impactó. */
    @Override
    protected void onHit(HitResult hit) {
        super.onHit(hit);
        if (level() instanceof ServerLevel server && !isRemoved()) {
            spawnAtLocation(server, getItem());
            discard();
        }
    }

    /** Entrega el ítem al lanzador (inventario) o lo suelta en el suelo. */
    private void deliver(ServerLevel server, ItemStack stack) {
        if (getOwner() instanceof Player player) {
            if (!player.getInventory().add(stack)) {
                player.drop(stack, false);
            }
        } else {
            spawnAtLocation(server, stack);
        }
    }
}
