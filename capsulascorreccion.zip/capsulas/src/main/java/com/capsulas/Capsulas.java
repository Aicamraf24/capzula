package com.capsulas;

import com.capsulas.entity.ModEntities;
import com.capsulas.item.ModItems;
import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;

public class Capsulas implements ModInitializer {
    public static final String MOD_ID = "capsulas";

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModEntities.init();
        ModItems.init();
    }
}
