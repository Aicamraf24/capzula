package com.capsulas;

import com.capsulas.entity.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.renderer.entity.ThrownItemRenderer;

public class CapsulasClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Dibuja la cápsula lanzada como un ítem volando (igual que una bola de nieve)
        EntityRendererRegistry.register(ModEntities.THROWN_CAPSULE, ThrownItemRenderer::new);
    }
}
