package com.capsulas.item;

import com.capsulas.entity.ThrownCapsule;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.stats.Stats;
import net.minecraft.util.ProblemReporter;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.boss.enderdragon.EnderDragon;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.TagValueInput;
import net.minecraft.world.level.storage.TagValueOutput;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;

import java.util.Optional;

public class CapsuleItem extends Item {
    public static final String TAG_MOB = "Mob";

    private final boolean filled;

    public CapsuleItem(Properties properties, boolean filled) {
        super(properties);
        this.filled = filled;
    }

    public boolean isFilled() {
        return filled;
    }

    /** Clic derecho: lanza la cápsula (vacía o llena) como un proyectil. */
    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        level.playSound(null, player.getX(), player.getY(), player.getZ(),
                SoundEvents.SNOWBALL_THROW, SoundSource.NEUTRAL, 0.5F,
                0.4F / (level.getRandom().nextFloat() * 0.4F + 0.8F));
        if (level instanceof ServerLevel server) {
            Projectile.spawnProjectileFromRotation(ThrownCapsule::new, server, stack, player, 0.0F, 1.5F, 1.0F);
        }
        player.awardStat(Stats.ITEM_USED.get(this));
        stack.consume(1, player);
        return InteractionResult.SUCCESS;
    }

    /** Cualquier Mob, salvo el Ender Dragon (es una entidad multiparte y no se puede guardar bien). */
    public static boolean canCapture(Mob mob) {
        return mob.isAlive() && !(mob instanceof EnderDragon);
    }

    /** Guarda el mob completo (vida, nombre, mascota, etc.) en una cápsula llena y lo quita del mundo. */
    public static ItemStack capture(ServerLevel level, Mob mob) {
        mob.ejectPassengers();
        mob.stopRiding();

        TagValueOutput out = TagValueOutput.createWithContext(ProblemReporter.DISCARDING, level.registryAccess());
        if (!mob.save(out)) {
            return null;
        }

        CompoundTag wrapper = new CompoundTag();
        wrapper.put(TAG_MOB, out.buildResult());

        ItemStack filledStack = new ItemStack(ModItems.CAPSULE_FILLED);
        filledStack.set(DataComponents.CUSTOM_DATA, CustomData.of(wrapper));
        filledStack.set(DataComponents.ITEM_NAME,
                Component.translatable("item.capsulas.capsule_filled_with", mob.getType().getDescription()));

        level.sendParticles(ParticleTypes.POOF, mob.getX(), mob.getY() + mob.getBbHeight() / 2, mob.getZ(),
                12, mob.getBbWidth() / 3, mob.getBbHeight() / 3, mob.getBbWidth() / 3, 0.02);
        level.playSound(null, mob.getX(), mob.getY(), mob.getZ(),
                SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 0.8F, 1.4F);

        mob.discard();
        return filledStack;
    }

    /** Recrea el mob guardado en el punto de impacto. Devuelve false si los datos no son válidos. */
    public static boolean release(ServerLevel level, ItemStack stack, BlockHitResult hit) {
        CustomData data = stack.get(DataComponents.CUSTOM_DATA);
        if (data == null) return false;

        Optional<CompoundTag> mobTag = data.copyTag().getCompound(TAG_MOB);
        if (mobTag.isEmpty()) return false;

        ValueInput input = TagValueInput.create(ProblemReporter.DISCARDING, level.registryAccess(), mobTag.get());
        Optional<Entity> created = EntityType.create(input, level, EntitySpawnReason.SPAWN_ITEM_USE);
        if (created.isEmpty()) return false;

        Entity entity = created.get();
        Vec3 p = hit.getLocation();
        Direction face = hit.getDirection();
        double half = entity.getBbWidth() / 2.0 + 0.05;

        double x = p.x + face.getStepX() * half;
        double z = p.z + face.getStepZ() * half;
        double y = face == Direction.DOWN ? p.y - entity.getBbHeight() : p.y;

        entity.setPos(x, y, z);
        entity.setDeltaMovement(Vec3.ZERO);
        level.addFreshEntityWithPassengers(entity);

        level.sendParticles(ParticleTypes.POOF, x, y + entity.getBbHeight() / 2, z,
                12, entity.getBbWidth() / 3, entity.getBbHeight() / 3, entity.getBbWidth() / 3, 0.02);
        level.playSound(null, x, y, z, SoundEvents.CHORUS_FRUIT_TELEPORT, SoundSource.PLAYERS, 0.8F, 1.2F);
        return true;
    }
}
